using System.Linq;
using CommonBehaviors.Actions;
using Singular.Dynamics;
using Singular.Helpers;
using Singular.Managers;
using Singular.Settings;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;
using Styx;

namespace Singular.ClassSpecific.Mage
{
    public static class Common
    {
        private static WoWItem _manaGem;

        [Class(WoWClass.Mage)]
        [Spec(TalentSpec.FireMage)]
        [Spec(TalentSpec.FrostMage)]
        [Spec(TalentSpec.ArcaneMage)]
        [Spec(TalentSpec.Lowbie)]
        [Behavior(BehaviorType.PreCombatBuffs)]
        [Context(WoWContext.All)]
        public static Composite CreateMageBuffs()
        {
            return new PrioritySelector(
                new Decorator(
                    ctx => StyxWoW.Me.CastingSpell != null && StyxWoW.Me.CastingSpell.Name == "Summon Water Elemental" && StyxWoW.Me.GotAlivePet,
                    new Action(ctx => SpellManager.StopCasting())),
                Spell.WaitForCast(),
                // Intellect buff: Arcane Brilliance (level 56+) or Arcane Intellect (level 1+) as fallback
                Spell.BuffSelf("Arcane Brilliance", ret => !StyxWoW.Me.HasAura("Arcane Intellect") && !StyxWoW.Me.HasAura("Fel Intelligence")),
                Spell.BuffSelf("Arcane Intellect", ret => !SpellManager.HasSpell("Arcane Brilliance") && !StyxWoW.Me.HasAura("Arcane Brilliance") && !StyxWoW.Me.HasAura("Fel Intelligence")),
                // Additional armors/barriers for BGs. These should be kept up at all times to ensure we're as survivable as possible.
                new Decorator(
                    ret => (SingularRoutine.CurrentWoWContext & WoWContext.Battlegrounds) != 0,
                    new PrioritySelector(
                // FA in BGs all the time. Damage reduction is win, and so is the slow. Serious PVPers will have this glyphed too, for the 2% mana regen.
                // WotLK: Ice Armor (L30+) is strictly superior to Frost Armor (more armor + freeze proc)
                        Spell.BuffSelf("Ice Armor"),
                        Spell.BuffSelf("Frost Armor", ret => !SpellManager.HasSpell("Ice Armor")),
                // WotLK: Fire Ward (Mage Ward doesn't exist until Cata)
                        Spell.BuffSelf("Fire Ward"),
                // Don't put up mana shield if we're arcane. Arcane damage scales with mana pool via Mind Mastery talent
                        Spell.BuffSelf("Mana Shield", ret => TalentManager.CurrentSpec != TalentSpec.ArcaneMage))),
                // We may not have it, but if we do, it should be up 100% of the time.
                Spell.BuffSelf("Ice Barrier"),
                // Outside of BGs: armor priority - Molten > Mage > Ice Armor > Frost Armor
                new Decorator(
                    ret => (SingularRoutine.CurrentWoWContext & WoWContext.Battlegrounds) == 0,
                    new PrioritySelector(
                // Arcane is a mana whore, we want molten if we don't have mage yet. Otherwise, stick with Mage armor.
                        Spell.BuffSelf("Molten Armor", ret => (TalentManager.CurrentSpec != TalentSpec.ArcaneMage || !SpellManager.HasSpell("Mage Armor"))),
                        Spell.BuffSelf("Mage Armor", ret => TalentManager.CurrentSpec == TalentSpec.ArcaneMage),
                // WotLK: Frost Armor / Ice Armor for low-level mages who don't have Molten or Mage Armor yet
                        Spell.BuffSelf("Ice Armor", ret => !SpellManager.HasSpell("Molten Armor") && !SpellManager.HasSpell("Mage Armor")),
                        Spell.BuffSelf("Frost Armor", ret => !SpellManager.HasSpell("Molten Armor") && !SpellManager.HasSpell("Mage Armor") && !SpellManager.HasSpell("Ice Armor")))),


                new PrioritySelector(ctx => MageTable,
                    new Decorator(ctx => ctx != null && CarriedMageFoodCount < 80 && StyxWoW.Me.FreeNormalBagSlots > 1,
                        new Sequence(
                            new Action(ctx => Logger.Write("Getting Mage food")),
                // Move to the Mage table
                            new DecoratorContinue(ctx => ((WoWGameObject)ctx).DistanceSqr > 5 * 5,
                                new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(StyxWoW.Me.Location, ((WoWGameObject)ctx).Location, 5))))),
                // interact with the mage table
                            new Action(ctx => ((WoWGameObject)ctx).Interact()),
                            new WaitContinue(2, ctx => false, new ActionAlwaysSucceed())))),

                new Decorator(ctx => SpellManager.CanCast("Ritual of Refreshment") && !Gotfood && ShouldSummonTable,
                    new Sequence(
                        new DecoratorContinue(ctx => StyxWoW.Me.IsMoving,
                            new Sequence(
                                new Action(ctx => WoWMovement.MoveStop()),
                                new WaitContinue(2, ctx => !StyxWoW.Me.IsMoving, new ActionAlwaysSucceed()))),
                        new Action(ctx => SpellManager.Cast("Ritual of Refreshment")),
                        new WaitContinue(2, ctx => StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(30, ctx => !StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()))),

                Spell.BuffSelf("Conjure Refreshment", ret => !Gotfood && !ShouldSummonTable),
                // WotLK: Conjure Food for levels below 74 (before Conjure Refreshment)
                new Decorator(
                    ret => SpellManager.CanCast("Conjure Food") && !Gotfood && !SpellManager.HasSpell("Conjure Refreshment"),
                    new Sequence(
                        new DecoratorContinue(ret => StyxWoW.Me.IsMoving,
                            new Sequence(
                                new Action(ret => WoWMovement.MoveStop()),
                                new WaitContinue(2, ret => !StyxWoW.Me.IsMoving, new ActionAlwaysSucceed()))),
                        new Action(ret => SpellManager.Cast("Conjure Food")),
                        new WaitContinue(2, ret => StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(10, ret => !StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(2, ret => Gotfood, new ActionAlwaysSucceed()))),
                // WotLK: Conjure Water for levels below 74 (before Conjure Refreshment)
                new Decorator(
                    ret => SpellManager.CanCast("Conjure Water") && !Gotwater && !SpellManager.HasSpell("Conjure Refreshment"),
                    new Sequence(
                        new DecoratorContinue(ret => StyxWoW.Me.IsMoving,
                            new Sequence(
                                new Action(ret => WoWMovement.MoveStop()),
                                new WaitContinue(2, ret => !StyxWoW.Me.IsMoving, new ActionAlwaysSucceed()))),
                        new Action(ret => SpellManager.Cast("Conjure Water")),
                        new WaitContinue(2, ret => StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(10, ret => !StyxWoW.Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(2, ret => Gotwater, new ActionAlwaysSucceed()))),

                Spell.BuffSelf("Conjure Mana Gem", ret => !HaveManaGem), //for dealing with managems
                new Decorator(
                    ret =>
                    TalentManager.CurrentSpec == TalentSpec.FrostMage && !StyxWoW.Me.GotAlivePet && PetManager.PetTimer.IsFinished && SpellManager.CanCast("Summon Water Elemental"),
                    new Action(ret => SpellManager.Cast("Summon Water Elemental")))
                );
        }

        // WotLK conjured food/refreshment item IDs (all ranks)
        private static readonly uint[] MageFoodIds = new uint[]
                                                         {
                                                             43523,  // Conjured Mana Strudel (req level 80)
                                                             43518,  // Conjured Mana Pie (req level 74)
                                                             34062,  // Conjured Mana Biscuit (req level 65)
                                                             22895,  // Conjured Cinnamon Roll (req level 55)
                                                             22019,  // Conjured Croissant (req level 65)
                                                             8076,   // Conjured Sweet Roll (level 35)
                                                             8075,   // Conjured Sourdough (level 25)
                                                             1487,   // Conjured Pumpernickel (level 15)
                                                             1114,   // Conjured Rye (level 5)
                                                             1113,   // Conjured Bread (level 1)
                                                             5349,   // Conjured Muffin
                                                         };
        // MageWaterIds added by xyFaded
        private static readonly uint[] MageWaterIds = new uint[]
                                                            {
                                                                22018,  // Conjured Glacier Water (65)
                                                                30703,  // Conjured Mountain Spring Water (60)
                                                                8079,   // Conjured Crystal Water (55)
                                                                8078,   // Conjured Sparkling Water (45)
                                                                8077,   // Conjured Mineral Water (35)
                                                                3772,   // Conjured Spring Water (25)
                                                                2136,   // Conjured Purified Water (15)
                                                                2288,   // Conjured Fresh Water (5)
                                                                5350,   // Conjured Water
                                                            };

        private const uint ArcanePowder = 17020;

        private static bool ShouldSummonTable
        {
            get
            {
                return SingularSettings.Instance.Mage.SummonTableIfInParty && SpellManager.HasSpell("Ritual of Refreshment") && StyxWoW.Me.BagItems.Any(i => i.Entry == ArcanePowder) &&
                       StyxWoW.Me.PartyMembers.Count(p => p.DistanceSqr < 40 * 40) >= 2;
            }
        }

       // WotLK: Only 186812 is the valid Refreshment Table (207386/207387 are Cata-only)
       static readonly uint[] RefreshmentTableIds = new uint[]
                                         {
                                             186812
                                         };

        static private WoWGameObject MageTable
        {
            get
            {
                return
                    ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(
                        i => RefreshmentTableIds.Contains(i.Entry) && (StyxWoW.Me.PartyMembers.Any(p => p.Guid == i.CreatedByGuid) || StyxWoW.Me.Guid == i.CreatedByGuid));
            }
        }

        private static int CarriedMageFoodCount
        {
            get
            {

                return (int)StyxWoW.Me.CarriedItems.Sum(i => i != null
                                                      && i.ItemInfo != null
                                                      && i.ItemInfo.ItemClass == WoWItemClass.Consumable
                                                      && i.ItemSpells != null
                                                      && i.ItemSpells.Count > 0
                                                      && i.ItemSpells[0].ActualSpell.Name.Contains("Refreshment")
                                                          ? i.StackCount
                                                          : 0);
            }
        }

        public static bool Gotfood { get { return StyxWoW.Me.BagItems.Any(item => MageFoodIds.Contains(item.Entry)); } }
        // Gotwater added by xyFaded
        public static bool Gotwater { get { return StyxWoW.Me.BagItems.Any(item => MageWaterIds.Contains(item.Entry)); } }

        // WotLK Mana Gem item IDs (Sapphire/Emerald/Ruby/Citrine/Jade/Agate)
        private static readonly uint[] ManaGemIds = new uint[] { 33312, 22044, 8008, 8007, 5513, 5514 };

        private static bool HaveManaGem { get { return StyxWoW.Me.BagItems.Any(i => ManaGemIds.Contains(i.Entry)); } }

        public static Composite CreateUseManaGemBehavior() { return CreateUseManaGemBehavior(ret => true); }

        public static Composite CreateUseManaGemBehavior(SimpleBooleanDelegate requirements)
        {
            return new PrioritySelector(
                ctx => StyxWoW.Me.BagItems.FirstOrDefault(i => ManaGemIds.Contains(i.Entry)),
                new Decorator(
                    ret => ret != null && StyxWoW.Me.ManaPercent < 100 && ((WoWItem)ret).Cooldown == 0 && requirements(ret),
                    new Sequence(
                        new Action(ret => Logger.Write("Using mana gem")),
                        new Action(ret => ((WoWItem)ret).Use())))
                );
        }

        public static Composite CreateStayAwayFromFrozenTargetsBehavior()
        {
            return new PrioritySelector(
                ctx => Unit.NearbyUnfriendlyUnits.
                           Where(
                               u => (u.HasAura("Frost Nova") || u.HasAura("Freeze")) &&
                                    u.Distance < Spell.MeleeRange).
                           OrderBy(u => u.DistanceSqr).FirstOrDefault(),
                new Decorator(
                    ret => ret != null && !SingularSettings.Instance.DisableAllMovement,
                    new PrioritySelector(
                        Spell.BuffSelf("Blink"),
                        new Action(
                            ret =>
                            {
                                WoWPoint moveTo =
                                    WoWMathHelper.CalculatePointBehind(
                                        ((WoWUnit)ret).Location,
                                        ((WoWUnit)ret).Rotation,
                                        -(Spell.MeleeRange + 5f));

                                if (Navigator.CanNavigateFully(StyxWoW.Me.Location, moveTo))
                                {
                                    Logger.Write("Getting away from frozen target");
                                    Navigator.MoveTo(moveTo);
                                    return RunStatus.Success;
                                }

                                return RunStatus.Failure;
                            }))));
        }

        public static Composite CreateMagePolymorphOnAddBehavior()
        {
            return
                new PrioritySelector(
                    ctx => Unit.NearbyUnfriendlyUnits.OrderByDescending(u => u.CurrentHealth).FirstOrDefault(IsViableForPolymorph),
                    new Decorator(
                        ret => ret != null && Unit.NearbyUnfriendlyUnits.All(u => !u.HasMyAura("Polymorph")),
                        new PrioritySelector(
                            Spell.Buff("Polymorph", ret => (WoWUnit)ret))));
        }

        private static bool IsViableForPolymorph(WoWUnit unit)
        {
            if (unit.IsCrowdControlled())
                return false;

            if (unit.CreatureType != WoWCreatureType.Beast && unit.CreatureType != WoWCreatureType.Humanoid)
                return false;

            if (StyxWoW.Me.CurrentTarget != null && StyxWoW.Me.CurrentTarget == unit)
                return false;

            if (!unit.Combat)
                return false;

            if (!unit.IsTargetingMeOrPet && !unit.IsTargetingMyPartyMember)
                return false;

            if (StyxWoW.Me.IsInParty && StyxWoW.Me.PartyMembers.Any(p => p.CurrentTarget != null && p.CurrentTarget == unit))
                return false;

            return true;
        }
    }
}
